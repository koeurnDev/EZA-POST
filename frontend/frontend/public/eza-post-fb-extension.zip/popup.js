/**
 * ============================================================
 * ⚡ EZA-POST Extension Popup Script (v2.2.0)
 * ============================================================
 */

const DEFAULT_SERVER_URL = "https://moneaa.site";

document.addEventListener("DOMContentLoaded", async () => {
  const fbStatusBadge = document.getElementById("fbStatusBadge");
  const statusDot = document.getElementById("statusDot");
  const fbUserText = document.getElementById("fbUserText");
  const btnSync = document.getElementById("btnSync");
  const btnSyncText = document.getElementById("btnSyncText");
  const btnOpenDashboard = document.getElementById("btnOpenDashboard");
  const messageBox = document.getElementById("messageBox");
  const messageContent = document.getElementById("messageContent");
  const extVersion = document.getElementById("extVersion");

  if (extVersion && chrome?.runtime?.getManifest) {
    extVersion.textContent = `v${chrome.runtime.getManifest().version || "2.2.0"}`;
  }

  let fbUserId = null;

  async function getEzaConnectionConfig() {
    const storageData = await chrome.storage.local.get(["serverUrl", "ezaAuthToken"]).catch(() => ({}));
    let serverUrl = storageData?.serverUrl || DEFAULT_SERVER_URL;
    let ezaAuthToken = storageData?.ezaAuthToken || "";

    try {
      const tabs = await chrome.tabs.query({
        url: [
          "https://moneaa.site/*",
          "https://*.moneaa.site/*",
          "https://*.pages.dev/*",
          "http://localhost:*/*",
          "http://127.0.0.1:*/*"
        ]
      });
      if (tabs && tabs.length > 0 && tabs[0].url) {
        const activeTab = tabs.find((t) => t.active) || tabs[0];
        const u = new URL(activeTab.url);
        serverUrl = u.origin;

        // Pull JWT directly from an already-open tab even if user hasn't refreshed after installing/updating extension
        if (!ezaAuthToken && activeTab.id && chrome?.scripting?.executeScript) {
          try {
            const [{ result }] = await chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              func: () => localStorage.getItem("eza_post_token") || localStorage.getItem("token") || ""
            });
            if (result) {
              ezaAuthToken = result;
              chrome.storage.local.set({ ezaAuthToken: result, serverUrl }).catch(() => {});
            }
          } catch (e) {}
        }
      }

      if (!ezaAuthToken && chrome?.cookies?.get) {
        const cookie = await chrome.cookies.get({ url: serverUrl, name: "token" }).catch(() => null);
        if (cookie?.value) {
          ezaAuthToken = cookie.value;
        }
      }
    } catch (e) {}

    return { serverUrl: serverUrl.replace(/\/$/, ""), ezaAuthToken };
  }

  function setOnlineState(userId) {
    fbStatusBadge.textContent = "Online";
    fbStatusBadge.className = "badge online";
    statusDot.className = "dot active";
    fbUserText.textContent = `បានរកឃើញគណនី FB: ${userId}`;
    btnSync.disabled = false;
  }

  function setOfflineState(message) {
    fbStatusBadge.textContent = "Offline";
    fbStatusBadge.className = "badge offline";
    statusDot.className = "dot";
    fbUserText.textContent = message;
    btnSync.disabled = true;
  }

  function showMessage(msg, type = "success") {
    messageBox.className = `message-box ${type}`;
    messageContent.textContent = msg;
    messageBox.classList.remove("hidden");
  }

  function checkFacebookSession() {
    chrome.runtime.sendMessage({ action: "CHECK_FB_STATUS" }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setOfflineState("មានបញ្ហាក្នុងការពិនិត្យសម័យ Facebook");
        return;
      }
      if (response.fbLoggedIn && response.fbUserId) {
        fbUserId = response.fbUserId;
        setOnlineState(fbUserId);
      } else {
        setOfflineState("សូម Login គណនី Facebook លើ Browser ជាមុនសិន");
      }
    });
  }

  btnSync.addEventListener("click", async () => {
    btnSync.disabled = true;
    btnSyncText.textContent = "កំពុងទាញយកទិន្នន័យពី Facebook...";

    chrome.runtime.sendMessage({ action: "GET_FB_SYNC_PAYLOAD" }, async (payload) => {
      if (chrome.runtime.lastError || !payload || !payload.ok) {
        showMessage(payload?.error || "សូម Login គណនី Facebook លើ Browser ជាមុនសិន!", "error");
        btnSync.disabled = false;
        btnSyncText.textContent = "ព្យាយាមម្តងទៀត";
        return;
      }

      const { serverUrl, ezaAuthToken } = await getEzaConnectionConfig();
      btnSyncText.textContent = "កំពុង Sync ផេកទៅកាន់ EZA-POST...";

      try {
        const headers = { "Content-Type": "application/json" };
        if (ezaAuthToken) {
          headers["Authorization"] = `Bearer ${ezaAuthToken}`;
        }

        const res = await fetch(`${serverUrl}/api/user/pages/connect-cookie`, {
          method: "POST",
          headers,
          credentials: "include",
          body: JSON.stringify({
            cookieOrToken: payload.accessToken || "active_extension_session",
            accessToken: payload.accessToken || null,
            adsToken: payload.adsToken || null,
            adsTokenVerified: Boolean(payload.adsTokenVerified),
            adAccounts: Array.isArray(payload.adAccounts) ? payload.adAccounts : [],
            fbUserId: payload.fbUserId || null,
            fbUser: payload.fbUser || null,
            pages: Array.isArray(payload.pages) ? payload.pages : []
          })
        });

        const data = await res.json().catch(() => ({}));

        if (data?.success) {
          const count = data.pagesCount ?? (data.pages ? data.pages.length : 0);
          const adsCount = data.adAccountsCount ?? (data.adAccounts ? data.adAccounts.length : 0);
          const adsStatus = adsCount > 0 ? (data.hasAdsToken ? ` + ${adsCount} Ad Accounts (PE Ready ✅)` : ` + ${adsCount} Ad Accounts (ខ្វះ Ads Token ⚠️)`) : "";
          const userName = payload.fbUser?.name || "គណនី Facebook";
          const countText = count > 0
            ? `បានភ្ជាប់ ${count} គោលដៅ${adsStatus}`
            : `បានភ្ជាប់គណនី ${userName}`;
          showMessage(
            `🎉 ជោគជ័យ! ${countText} ទៅកាន់ EZA-POST រួចរាល់!`,
            "success"
          );
          btnSyncText.textContent = "✅ Sync ជោគជ័យ!";

          setTimeout(() => {
            chrome.tabs.create({ url: `${serverUrl}/connections` });
          }, 1200);
        } else {
          showMessage(
            `សូមបើកទំព័រ EZA-POST រួចចុចប៊ូតុង Sync នៅលើវេបសាយផ្ទាល់ (${data?.error || "Unauthorized"})`,
            "error"
          );
          btnSyncText.textContent = "ព្យាយាមម្តងទៀត";
          btnSync.disabled = false;
        }
      } catch (err) {
        showMessage(
          "សូមបើកទំព័រភ្ជាប់ផេក EZA-POST រួចចុចប៊ូតុង Sync នៅលើវេបសាយផ្ទាល់!",
          "error"
        );
        btnSyncText.textContent = "ព្យាយាមម្តងទៀត";
        btnSync.disabled = false;
      }
    });
  });

  btnOpenDashboard.addEventListener("click", async () => {
    const { serverUrl } = await getEzaConnectionConfig();
    chrome.tabs.create({ url: `${serverUrl}/connections` });
  });

  checkFacebookSession();
});
